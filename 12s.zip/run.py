import os, time

botStart = time.time()
try:os.system('./new a1 & ./new a2 & ./new a3 & ./new a4')
except:pass
